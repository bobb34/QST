use lib qw(/home);
use lib qw(/usr/local/lib/x86_64-linux-gnu/perl/5.22.1);
use strict; 
use File::Path;
use Net::LDAP;
use POSIX qw(strftime);
use Crypt::PBKDF2;
use Apache::DBI;
use DBI;
DBI->install_driver("mysql");

  1;

