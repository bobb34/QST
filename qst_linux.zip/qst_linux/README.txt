We release versions of QST on a regular basis.

Version 3.0.0 was the latest major release on Mar 21, 2020.

Version 3.03.02 is our latest release.

   - To upgrade from previous versions of 3.01.xx run the following in MySQL:
        mysql> alter table posted_qst add column shuffle_ans int(1);
        mysql> alter table users add column photo varchar(15);
        
        Under /qst/schools/qst_files add directory photos
        
    - To upgrade from previous versions of 3.02.xx run the following in MySQL:
        mysql> alter table users add column photo varchar(15);
        
        Under /qst/schools/qst_files add directory photos


Version 3.0.xx are bug fixes, minor code changes, code clean up or new features.
  These versions of QST will run with the database you already have.
  Bugs are fixed as quickly as possible.

Version 3.x are database changes and you will have to run a database script to alter your previous database to work with this new version of QST.

QST.zip is rather large because it contains the files to install QST on Windows.

QST.pm (the program) is only 2.9 MB.


  


