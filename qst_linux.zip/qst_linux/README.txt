qst.zip is rather large because it contains the files to install perl and MySQL and Apache on Windows.
Download qst_linux.zip if you are doing a linux install.
QST.pm (the program) is only 2.9 MB.

We release versions of QST on a regular basis.

Version 3.0.0 was the latest major release on Mar 21, 2020.

Version 3.04.01 is our latest release.

   - To upgrade from previous versions of 3.01.xx run the following in MySQL:
        mysql> alter table posted_qst add column shuffle_ans int(1);
        mysql> alter table users add column photo varchar(15);
        mysql> alter table questions add column pdf int(10);
        
        Under /qst/schools/qst_files add directory photos
        
    - To upgrade from previous versions of 3.02.xx run the following in MySQL:
        mysql> alter table users add column photo varchar(15);
        mysql> alter table questions add column pdf int(10);
        
        Under /qst/schools/qst_files add directory photos

    - To upgrade from previous versions of 3.03.xx run the following in MySQL:
        mysql> alter table questions add column pdf int(10);
        
Version 3.0.xx are bug fixes, minor code changes, code clean up or new features.
  These versions of QST will run with the database you already have.
  Bugs are fixed as quickly as possible.

Version 3.x are database changes and you will have to run a database script to alter your previous database to work with this new version of QST.



  


